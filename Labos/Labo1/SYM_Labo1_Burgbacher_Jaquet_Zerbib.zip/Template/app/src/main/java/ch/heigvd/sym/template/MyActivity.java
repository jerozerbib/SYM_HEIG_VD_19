package ch.heigvd.sym.template;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.Objects;


public class MyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle(R.string.activity_name);
        setContentView(R.layout.activity_my);


        //image from sdcard and verification permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

            File image = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "perso.jpg");
            ImageView jpgView = findViewById(R.id.imageView);
            jpgView.setImageBitmap(Bitmap.createBitmap(BitmapFactory.decodeFile(image.getAbsolutePath())));
        }

        //email
        Intent intent = getIntent();

        String email = "";
        if (intent != null) {
            email = intent.getStringExtra("emailEntered");
        }

        TextView emailDisplay = findViewById(R.id.textView);
        emailDisplay.setText(email);

        TextView deviceIDDisplay = findViewById(R.id.textView2);
        String deviceID;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                deviceID = Objects.requireNonNull(telephonyManager).getImei();
            } else {
                deviceID = Objects.requireNonNull(telephonyManager).getDeviceId();
            }
        } else {
            deviceID = "Permission is not Granted -> No IMEI to display";
        }

        deviceIDDisplay.setText(deviceID);

        // To transfer id to fist activity
        // This is for the question 4
        /*
        Intent intentfirst = new Intent();
        intentfirst.putExtra("deviceID", deviceID);
        setResult(1, intentfirst);
         */

    }
}




